cat > npm/getBinary.js << 'EOF'
const https = require('https');
const fs    = require('fs');
const path  = require('path');
const pkg   = require('../package.json');

const PLATFORM_MAP = { darwin: 'macos', linux: 'linux', win32: 'windows' };
const ARCH_MAP     = { x64: 'x86_64', arm64: 'aarch64' };

function getUrl() {
  const platform = PLATFORM_MAP[process.platform];
  const arch     = ARCH_MAP[process.arch];
  if (!platform || !arch) {
    throw new Error(`Unsupported: ${process.platform} ${process.arch}`);
  }
  const v = pkg.version;
  return {
    url:      `https://github.com/GTgyani206/nexus/releases/download/v${v}/nexus_${v}_${platform}_${arch}.tar.gz`,
    binName:  process.platform === 'win32' ? 'nexus.exe' : 'nexus',
    binDir:   path.join(__dirname, '..', 'bin'),
  };
}

function follow(url, cb) {
  https.get(url, { headers: { 'User-Agent': 'nexus-install' } }, res => {
    if (res.statusCode === 301 || res.statusCode === 302) return follow(res.headers.location, cb);
    cb(res);
  }).on('error', e => { console.error('Network error:', e.message); process.exit(1); });
}

function install() {
  const { url, binName, binDir } = getUrl();
  console.log('Downloading:', url);
  if (!fs.existsSync(binDir)) fs.mkdirSync(binDir, { recursive: true });

  follow(url, res => {
    if (res.statusCode !== 200) {
      console.error(`HTTP ${res.statusCode} — binary not found at:\n  ${url}`);
      console.error('Fallback: cargo install --git https://github.com/GTgyani206/nexus');
      process.exit(1);
    }
    const chunks = [];
    res.on('data', c => chunks.push(c));
    res.on('end', () => {
      const tar = require('child_process').spawnSync(
        'tar', ['-xz', '-C', binDir],
        { input: Buffer.concat(chunks), stdio: ['pipe','inherit','inherit'] }
      );
      if (tar.status !== 0) { console.error('tar extraction failed'); process.exit(1); }
      const binPath = path.join(binDir, binName);
      try { fs.chmodSync(binPath, 0o755); } catch(_) {}
      console.log('Installed:', binPath);
    });
  });
}

function run() {
  const { binDir, binName } = getUrl();
  const binPath = path.join(binDir, binName);
  if (!fs.existsSync(binPath)) {
    console.error('nexus binary not found. Try: npm install -g nexus-lang');
    process.exit(1);
  }
  const result = require('child_process').spawnSync(binPath, process.argv.slice(2), { stdio: 'inherit' });
  process.exit(result.status ?? 1);
}

module.exports = { install, run };
EOF
