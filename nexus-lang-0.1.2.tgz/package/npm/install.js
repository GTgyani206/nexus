require('./getBinary').install();
